import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { AuthService } from '../../services/services/auth.service';
import { UserDetailComponent } from '../personal-details/personal-details.component';
import { Router, RouterModule } from '@angular/router'; // ייבוא RouterModule עבור קישורים ב-HTML
import { AppButtonComponent } from '../buton-basic/buton-basic.component';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule, 
    RouterModule,       // הוספנו RouterModule במקום Router
    UserDetailComponent ,
     AppButtonComponent
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  // הזרקת ה-Router ב-Constructor כדי שנוכל לנווט בין דפים
  constructor(
    public authService: AuthService,
    private router: Router 
  ) {}

  // handleUpgradeRequest() {
  //   console.log("התקבלה בקשת שדרוג מהבן!");
  //   alert("בקשתך להפוך למעלה תוכן נשלחה לאדמין.");
  // }

  //הגשת בקשה
//   handleUpgradeRequest() {
//   const userEmail = this.authService.currentUser.email;

//   this.authService.requestUpgrade(userEmail).subscribe({
//     next: (res) => {
//       alert(res.message); // "בקשת השדרוג נקלטה..."
//       // בגלל ה-tap ב-Service, ה-UI יתעדכן אוטומטית והכפתור ייעלם
//     },
//     error: (err) => {
//       console.error("שגיאה בשדרוג", err);
//       alert("חלה שגיאה בשליחת הבקשה.");
//     }
//   });
// }

// profile.component.ts

// handleUpgradeRequest() {
//   const email = this.authService.currentUser?.email;
  
//   if (email) {
//     this.authService.requestUpgrade(email).subscribe({
//       next: (res) => {
//         alert("הבקשה נשלחה! סטטוס המשתמש שלך עודכן ל-'ממתין'.");
//         // בגלל ה-tap ב-service, ה-HTML יתעדכן לבד
//       },
//       error: (err) => {
//         alert("חלה שגיאה בשליחת הבקשה.");
//       }
//     });
//   }
// }

// profile.component.ts
handleUpgradeRequest() {
  const email = this.authService.currentUser?.email;
  
  if (!email) {
    console.error("לא נמצא אימייל למשתמש הנוכחי");
    return;
  }

  this.authService.requestUpgrade(email).subscribe({
    next: (res: any) => { // הגדרת res כ-any פותרת שגיאות זיהוי
      console.log("הצלחה:", res);
      alert(res.message || "הבקשה נשלחה!");
    },
    error: (err: any) => { // הגדרת err כ-any
      console.error("שגיאה מלאה מהשרת:", err);
      alert("שגיאה: " + (err.error?.message || "חלה שגיאה בחיבור לשרת"));
    }
  });
}

  handleUpgrade() {
    console.log("שולח בקשה לשרת...");
  }

  goToAddRecipe() {
    // התיקון: שימוש ב-this.router כדי לנווט
    this.router.navigate(['/add-recipe']);
  }
  goToAdmin() {
    this.router.navigate(['/admin-management']);
  }
}