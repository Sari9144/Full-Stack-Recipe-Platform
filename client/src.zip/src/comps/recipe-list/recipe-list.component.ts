import { Component, OnInit } from '@angular/core';
import { RecipeService } from '../../services/recipe.service';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router'; // ייבוא הראוטר לניווט

@Component({
  selector: 'app-recipe-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes: any[] = [];
  baseUrl = 'http://127.0.0.1:5000';

  constructor(private recipeService: RecipeService, private router: Router) {}

  ngOnInit(): void {
    this.recipeService.getAllRecipes().subscribe(data => this.recipes = data);
  }

  // פונקציה למעבר לדף פרטים נוספים
  viewDetails(id: number) {
    this.router.navigate(['/recipe-details', id]);
  }
}