// // import { Component, inject } from '@angular/core';
// // import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// // import { AuthService } from '../../services/services/auth.service';

// // @Component({
// //   selector: 'app-login',
// //   standalone: true,
// //   imports: [ReactiveFormsModule], // אין צורך ב-CommonModule עבור @if
// //   templateUrl: './login.component.html',
// //   styleUrls: ['./login.component.css']
// // })
// // export class LoginComponent {
// //   // שימוש ב-inject במקום ב-Constructor (סגנון מודרני של אנגולר)
// //   private fb = inject(FormBuilder);
// //   private authService = inject(AuthService);

// //   loginForm: FormGroup = this.fb.group({
// //     email: ['', [Validators.required, Validators.email]],
// //     password: ['', [Validators.required, Validators.minLength(4)]]
// //   });

// //   errorMessage = '';

// //   onSubmit() {
// //     if (this.loginForm.valid) {
// //       this.authService.login(this.loginForm.value).subscribe({
// //         next: (res) => {
// //           console.log('התחברת בהצלחה', res);
// //           // כאן נוסיף בהמשך ניתוב לדף אחר
// //         },
// //         error: (err) => {
// //           this.errorMessage = 'שגיאה בהתחברות, בדקי את הפרטים';
// //         }
// //       });
// //     }
// //   }
// // }

// import { Component, inject } from '@angular/core';
// import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { AuthService } from '../../services/services/auth.service';
// import { Router } from '@angular/router'; // הוספנו את הראוטר


// @Component({
//   selector: 'app-login',
//   standalone: true,
//   imports: [ReactiveFormsModule],
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent {
//   private fb = inject(FormBuilder);
//   private authService = inject(AuthService);
//   private router = inject(Router); // הזרקת הראוטר

//   // הגדרת הטופס
//   loginForm: FormGroup = this.fb.group({
//     email: ['', [Validators.required, Validators.email]],
//     password: ['', [Validators.required, Validators.minLength(3)]]
//   });

//   errorMessage = '';
//   welcomeMessage = ''; // משתנה להצגת הודעת הצלחה בממשק

//   onSubmit() {
//     if (this.loginForm.valid) {
//       this.authService.login(this.loginForm.value).subscribe({
//         next: (res: any) => {
//           // הצלחה: השרת מחזיר סטטוס 200
//           this.errorMessage = '';
//           this.welcomeMessage = res.message; // "שלום ל..." שמגיע מה-Python
          
//           console.log('התחברת בהצלחה:', res.user);
          
//           // אופציונלי: מעבר לדף הבית/לוח בקרה אחרי הצלחה
//           setTimeout(() => this.router.navigate(['/home']), 1500);
//         },
//         error: (err) => {
//           this.welcomeMessage = '';
//           console.log('Status code received:', err.status);
//     console.log('Body received:', err.error); // תראי אם יש כאן action: 'redirect_to_register'
//           // בדיקה האם השרת החזיר 404 (משתמש לא נמצא)
//           if (err.status === 401 && err.error.action === 'redirect_to_register') {
//             console.log('משתמש לא קיים, עובר להרשמה');
//             alert("!!משתמש לא קיים, יש להרשם ")
//             this.router.navigate(['/register']);
//           } else if (err.status === 401) {
//             this.errorMessage = 'סיסמה שגויה, נסי שוב';
//           } else {
//             this.errorMessage = 'שגיאה בחיבור לשרת, נסי מאוחר יותר';
//           }
//         }
//       });
//     }
//   }
// }

import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(3)]]
  });

  errorMessage = '';
  welcomeMessage = '';

  onSubmit() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe({
        next: (res: any) => {
          this.errorMessage = '';
          this.welcomeMessage = `שלום ${res.user.username}, התחברת בהצלחה!`;
          
          console.log('User Data:', res.user);
          
          // ניתוב לדף הבית לאחר הצלחה
          setTimeout(() => this.router.navigate(['/home']), 1500);
        },
        error: (err) => {
          this.welcomeMessage = '';
          const serverError = err.error;

          // 1. משתמש לא קיים - הפניה לרישום (סטטוס 404 כפי שהגדרנו בשרת)
          if (err.status === 404 && serverError.action === 'redirect_to_register') {
            console.log('Redirecting to register...');
            alert(serverError.message || "משתמש לא קיים, עובר לדף הרשמה");
            this.router.navigate(['/register']);
          } 
          // 2. סיסמה שגויה (סטטוס 401)
          else if (err.status === 401) {
            this.errorMessage = serverError.message || 'סיסמה שגויה, נסי שוב';
          } 
          // 3. שגיאות אחרות (שרת למטה וכדומה)
          else {
            this.errorMessage = 'שגיאה בתקשורת עם השרת, נסי שוב מאוחר יותר';
          }
        }
      });
    }
  }
}