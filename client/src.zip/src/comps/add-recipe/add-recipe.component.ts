// import { Component } from '@angular/core';
// import { RecipeService } from '../../services/recipe.service';
// import { FormsModule } from '@angular/forms';

// // @Component({
// //   selector: 'app-add-recipe',
// //   templateUrl: './add-recipe.component.ts', // תכף ניצור את ה-HTML
// // })
// // @Component({
// //   selector: 'app-add-recipe',
// //   imports: [FormsModule],
// //   templateUrl: './add-recipe.component.html', // <--- האם בטעות כתבת כאן .ts במקום .html?
// //   styleUrls: ['./add-recipe.component.css']
// // })

// import { CommonModule } from '@angular/common'; // הוסיפי ייבוא

// @Component({
//   selector: 'app-add-recipe',
//   standalone: true, // אם כתוב כאן true
//   imports: [CommonModule, FormsModule], // הוסיפי כאן את CommonModule
//   templateUrl: './add-recipe.component.html',
//   styleUrls: ['./add-recipe.component.css']
// })
// export class AddRecipeComponent {
//   recipe = { title: '', type: 'Parve' };
//   ingredients: any[] = [{ product: '', amount: 0, unit: '' }];
//   selectedFile: File | null = null;

//   constructor(private recipeService: RecipeService) {}

//   // הוספת שורה לרשימת הרכיבים בטופס
//   addIngredientRow() {
//     this.ingredients.push({ product: '', amount: 0, unit: '' });
//   }

//   // שמירת הקובץ שנבחר מהמחשב
//   onFileSelected(event: any) {
//     this.selectedFile = event.target.files[0];
//   }

//   submitRecipe() {
//     if (!this.selectedFile) {
//       alert("חובה לבחור תמונה!");
//       return;
//     }

//     // יצירת אובייקט FormData (חובה בשביל קבצים)
//     const formData = new FormData();
//     formData.append('title', this.recipe.title);
//     formData.append('type', this.recipe.type);
//     formData.append('image', this.selectedFile);
    
//     // את הרכיבים (המערך) אנחנו שולחים כמחרוזת JSON
//     formData.append('ingredients', JSON.stringify(this.ingredients));

//     this.recipeService.addRecipe(formData).subscribe({
//       next: (res) => alert("המתכון עלה בהצלחה!"),
//       error: (err) => console.error("שגיאה בהעלאה", err)
//     });
//   }

//   removeIngredient(index: number) {
//   this.ingredients.splice(index, 1);
// }
// }

import { Component, inject } from '@angular/core';
import { RecipeService } from '../../services/recipe.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-recipe',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-recipe.component.html',
  styleUrls: ['./add-recipe.component.css']
})
export class AddRecipeComponent {
  private recipeService = inject(RecipeService);

  // הוספת השדות החדשים לאובייקט
  recipe = { 
    title: '', 
    type: 'Parve', 
    instructions: '', 
    prep_time: 0, 
    category: '', 
    created_by_name: '' 
  };
  
  ingredients: any[] = [{ product: '', amount: 0, unit: '' }];
  selectedFile: File | null = null;

  addIngredientRow() {
    this.ingredients.push({ product: '', amount: 0, unit: '' });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  submitRecipe() {
    if (!this.selectedFile) {
      alert("חובה לבחור תמונה!");
      return;
    }

    const formData = new FormData();
    formData.append('title', this.recipe.title);
    formData.append('type', this.recipe.type);
    formData.append('image', this.selectedFile);
    
    // הוספת השדות החדשים ל-FormData
    formData.append('instructions', this.recipe.instructions);
    formData.append('prep_time', this.recipe.prep_time.toString());
    formData.append('category', this.recipe.category);
    formData.append('created_by_name', this.recipe.created_by_name);

    formData.append('ingredients', JSON.stringify(this.ingredients));

    this.recipeService.addRecipe(formData).subscribe({
      next: (res) => alert("המתכון עלה בהצלחה!"),
      error: (err) => console.error("שגיאה בהעלאה", err)
    });
  }

  removeIngredient(index: number) {
    this.ingredients.splice(index, 1);
  }
}