import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from '../../services/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  errorMessage = '';

  // בניית הטופס לפי השדות במסד הנתונים
  registerForm: FormGroup = this.fb.group({
  username: ['', [Validators.required, Validators.minLength(2)]], // השדה החדש
  email: ['', [Validators.required, Validators.email]],
  password: ['', [Validators.required, Validators.minLength(3)]],
  role: ['Reader']
});
  onSubmit() {
    if (this.registerForm.valid) {
      this.authService.register(this.registerForm.value).subscribe({
        next: (res) => {
          console.log('Registration success', res);
          alert('נרשמת בהצלחה! כעת תוכל להתחבר.');
          this.router.navigate(['/home']); // מעבר לדף כניסה אחרי הרשמה
        },
        error: (err) => {
          console.error(err);
          this.errorMessage = err.error?.message || 'שגיאה ברישום המשתמש';
        }
      });
    }
  }
}