import { Component, OnInit, inject } from '@angular/core';
import { AuthService } from '../../services/services/auth.service';
import { UserDetailComponent } from '../personal-details/personal-details.component'; // ייבוא הבן של הפרטים
import { AppButtonComponent } from '../buton-basic/buton-basic.component'; // ייבוא הבן של הכפתור

@Component({
  selector: 'app-admin-management',
  standalone: true,
  imports: [UserDetailComponent, AppButtonComponent], // רישום הבנים
  templateUrl: './show-users.component.html',
  styleUrl: './show-users.component.css'
})
export class AdminManagementComponent implements OnInit {
  authService = inject(AuthService);
  pendingUsers: any[] = [];

  ngOnInit() {
    this.loadPendingUsers();
  }

  loadPendingUsers() {
    this.authService.getPendingUsers().subscribe({
      next: (users) => this.pendingUsers = users,
      error: (err) => console.error("שגיאה בטעינת משתמשים", err)
    });
  }

  approve(userId: number) {
    this.authService.approveUser(userId).subscribe({
      next: (res) => {
        alert(res.message);
        this.loadPendingUsers(); // רענון הרשימה
      }
    });
  }
}