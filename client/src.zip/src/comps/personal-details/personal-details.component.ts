import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-user-detail',
  standalone: true,
  imports: [],
  templateUrl: './personal-details.component.html', 
  styleUrl: './personal-details.component.css'
})
export class UserDetailComponent {
  @Input() userData: any;
}