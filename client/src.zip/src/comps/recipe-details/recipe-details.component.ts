import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // חשוב עבור *ngIf ו-*ngFor
import { ActivatedRoute } from '@angular/router'; // בשביל לקרוא את ה-ID מהכתובת
import { RecipeService } from '../../services/recipe.service'; // ודאי שהנתיב ל-Service נכון

@Component({
  selector: 'app-recipe-details',
  standalone: true, // אם את משתמשת בגרסאות החדשות
  imports: [CommonModule], // מאפשר להשתמש ב-ngIf ו-ngFor ב-HTML
  templateUrl: './recipe-details.component.html',
  styleUrl: './recipe-details.component.css'
})
// export class RecipeDetailsComponent implements OnInit {
//   // הגדרת המשתנה שיחזיק את נתוני המתכון
//   recipe: any;
//   baseUrl = 'http://127.0.0.1:5000'; // כתובת השרת לתמונות

//   constructor(
//     private route: ActivatedRoute, 
//     private recipeService: RecipeService
//   ) {}

//   ngOnInit(): void {
//     // 1. שליפת ה-ID מה-URL (למשל מתוך recipes/5)
//     const id = this.route.snapshot.paramMap.get('id');
    
//     if (id) {
//       // 2. קריאה לשרת להבאת נתוני המתכון הספציפי
//       this.recipeService.getRecipeById(+id).subscribe({
//         next: (data) => {
//           this.recipe = data;
//           console.log('Recipe details loaded:', data);
//         },
//         error: (err) => {
//           console.error('Error fetching recipe details:', err);
//         }
//       });
//     }
//   }

//   // פונקציה לחזרה אחורה (אופציונלי)
//   goBack(): void {
//     window.history.back();
//   }
// }

export class RecipeDetailsComponent implements OnInit {
  recipe: any;
  baseUrl = 'http://127.0.0.1:5000';
  
  // 1. הוסיפי את השורה הזו (הגדרת המשתנה)
  currentImage: string = ''; 

  constructor(
    private route: ActivatedRoute,
    private recipeService: RecipeService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.recipeService.getRecipeById(+id).subscribe({
        next: (data) => {
          this.recipe = data;
          // 2. אופציונלי: הגדרת התמונה המקורית כתמונה הראשונה שרואים
          this.currentImage = this.baseUrl + data.main_image;
        },
        error: (err) => console.error(err)
      });
    }
  }

  // 3. הוסיפי את הפונקציה הזו כדי שהלחיצה ב-HTML תעבוד
  setMainImage(url: string) {
    this.currentImage = url;
  }

  goBack() {
    window.history.back();
  }
}