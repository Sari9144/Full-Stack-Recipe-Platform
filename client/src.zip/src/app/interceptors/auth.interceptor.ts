// import { HttpInterceptorFn } from '@angular/common/http';

// export const authInterceptor: HttpInterceptorFn = (req, next) => {
//   return next(req);
// };

import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../../services/services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const user = authService.currentUser;

  // אם המשתמש מחובר, נשכפל את הבקשה ונוסיף לה את ה-Header
  if (user && user.role) {
    const authReq = req.clone({
      setHeaders: {
        'x-user-role': user.role
      }
    });
    return next(authReq);
  }

  // אם המשתמש לא מחובר, נשלח את הבקשה המקורית כמו שהיא
  return next(req);
};