import { Routes } from '@angular/router';
import { LoginComponent } from '../comps/login/login.component';
import { RegisterComponent } from '../comps/register/register.component';
import { HomeComponent } from '../comps/home/home.component';
import { RecipeListComponent } from '../comps/recipe-list/recipe-list.component';
import { AddRecipeComponent } from '../comps/add-recipe/add-recipe.component';
import { ProfileComponent } from '../comps/profile/profile.component';
import { AdminManagementComponent } from '../comps/show-users/show-users.component';
import { roleGuard } from '../auth.guard';
import { RecipeDetailsComponent } from '../comps/recipe-details/recipe-details.component';

export const routes: Routes = [
  // דף הבית והרשמה/התחברות
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'recipes', component: RecipeListComponent },
  { path: 'recipe-details/:id', component: RecipeDetailsComponent },
  { path: 'personal-details', component: ProfileComponent },

  // נתיב המנהל - מוגן על ידי שומר הסף
  { 
    path: 'admin-management', 
    component: AdminManagementComponent, 
    canActivate: [roleGuard('Admin')] 
  },

  // נתיב הוספת מתכון - מוגן למעלי תוכן
  { 
    path: 'add-recipe', 
    component: AddRecipeComponent, 
    canActivate: [roleGuard('Uploader')] 
  },

  // ברירת מחדל - אם הנתיב ריק, נווט לבית
  { path: '', component: HomeComponent, pathMatch: 'full' },

  // הגנה מפני דפים לא קיימים - תמיד אחרון!
  { path: '**', redirectTo: 'home' }
];