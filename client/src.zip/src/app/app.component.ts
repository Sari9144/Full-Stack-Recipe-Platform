// import { Component } from '@angular/core';
// import { RouterOutlet } from '@angular/router';
// import { LoginComponent } from '../comps/login/login.component';
// import { RegisterComponent } from '../comps/register/register.component';

// @Component({
//   selector: 'app-root',
//   imports: [RouterOutlet,LoginComponent,RegisterComponent],
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'myProject';
// }


import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { AuthService } from '../services/services/auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink,FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // הזרקת ה-Service כ-public כדי שה-HTML יזהה אותו
  public authService = inject(AuthService);
// app.component.ts
// testInterceptor() {
//   this.authService.checkServerStatus().subscribe({
//     next: (res) => console.log('תגובת השרת:', res),
//     error: (err) => console.error('שגיאה:', err)
//   });
// }
  logout() {
    this.authService.logout();
  }
}