import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './services/services/auth.service';

/**
 * שומר סף גנרי שבודק תפקיד משתמש
 * @param expectedRole התפקיד הנדרש כדי להיכנס לנתיב
 */
export const roleGuard = (expectedRole: string): CanActivateFn => {
  return () => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const user = authService.currentUser;

    // 1. בדיקה האם המשתמש מחובר בכלל
    if (!user) {
      router.navigate(['/login']);
      return false;
    }

    // 2. בדיקה האם המשתמש הוא מנהל (מנהל תמיד יכול להיכנס)
    if (user.role === 'Admin') {
      return true;
    }

    // 3. בדיקה האם התפקיד של המשתמש תואם לתפקיד המצופה
    if (user.role === expectedRole) {
      return true;
    }

    // אם אין הרשאה - שלח אותו לדף הבית
    alert('אין לך הרשאה לגשת לדף זה');
    router.navigate(['/']);
    return false;
  };
};