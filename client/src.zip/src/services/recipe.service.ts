import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './services/auth.service'; // נצטרך את התפקיד מה-Auth

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  private apiUrl = 'http://127.0.0.1:5000/recipes';

  constructor(private http: HttpClient, private authService: AuthService) {}

  // פונקציה להוספת מתכון - משתמשת ב-FormData
  addRecipe(recipeData: FormData): Observable<any> {
    // שליפת התפקיד מה-AuthService לצורך הדקורטור בשרת
    const role = this.authService.currentUser?.role || '';
    
    const headers = new HttpHeaders({
      'x-user-role': role // ה-Header שהדקורטור שלנו מחפש
    });

    return this.http.post(`${this.apiUrl}/add`, recipeData, { headers });
  }

  // שליפת כל המתכונים לגלריה
  getAllRecipes(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/all`);
  }

  // recipe.service.ts
getRecipeById(id: number): Observable<any> {
  return this.http.get<any>(`${this.apiUrl}/${id}`);
}
}