// // // // // import { Injectable, inject } from '@angular/core';
// // // // // import { HttpClient } from '@angular/common/http';
// // // // // import { Observable } from 'rxjs';

// // // // // @Injectable({
// // // // //   providedIn: 'root'
// // // // // })
// // // // // export class AuthService {
// // // // //   // ה-inject מחליף את ה-Constructor
// // // // //   private http = inject(HttpClient);
  
// // // // //   // הכתובת של השרת שלך (וודאי שה-Prefix תואם למה שהגדרת ב-Blueprint)
// // // // //   private apiUrl = 'http://127.0.0.1:5000/auth';

// // // // //   constructor() { }

// // // // //   // פונקציית התחברות
// // // // //   login(credentials: any): Observable<any> {
// // // // //     return this.http.post(`${this.apiUrl}/login`, credentials);
// // // // //   }

// // // // //   // פונקציית הרשמה
// // // // //   register(userData: any): Observable<any> {
// // // // //     return this.http.post(`${this.apiUrl}/register`, userData);
// // // // //   }
// // // // // }

// // // // import { Injectable, inject } from '@angular/core';
// // // // import { HttpClient } from '@angular/common/http';
// // // // import { Observable, tap } from 'rxjs';

// // // // @Injectable({
// // // //   providedIn: 'root'
// // // // })
// // // // export class AuthService {
// // // //   private http = inject(HttpClient);
// // // //   private apiUrl = 'http://127.0.0.1:5000/auth';

// // // //   // המשתנה שיחזיק את נתוני המשתמש המחובר לכל אורך חיי האפליקציה
// // // //   public currentUser: any = null;

// // // //   constructor() {
// // // //     // כשמפעילים את האפליקציה, בודקים אם יש משתמש בזיכרון של הדפדפן
// // // //     const savedUser = localStorage.getItem('user');
// // // //     if (savedUser) {
// // // //       this.currentUser = JSON.parse(savedUser);
// // // //     }
// // // //   }

// // // //   // פונקציית כניסה
// // // //   login(credentials: any): Observable<any> {
// // // //     return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
// // // //       tap((res: any) => {
// // // //         // ברגע שהתקבל אישור מהשרת, שומרים את האובייקט ב-Service
// // // //         this.currentUser = res.user;
// // // //         // ושומרים בזיכרון הדפדפן כדי שברענון דף המשתמש לא יתנתק
// // // //         localStorage.setItem('user', JSON.stringify(res.user));
// // // //       })
// // // //     );
// // // //   }

// // // //   // פונקציית הרשמה
// // // //   register(userData: any): Observable<any> {
// // // //     return this.http.post(`${this.apiUrl}/register`, userData);
// // // //   }
// // // // // auth.service.ts
// // // // // checkServerStatus() {
// // // // //   return this.http.get('http://127.0.0.1:5000/auth/check-status');
// // // // // }
// // // //   // התנתקות
// // // //   logout() {
// // // //     this.currentUser = null;
// // // //     localStorage.removeItem('user');
// // // //   }
// // // // }

// // // import { Injectable, inject } from '@angular/core';
// // // import { HttpClient } from '@angular/common/http';
// // // import { Observable, tap } from 'rxjs';

// // // @Injectable({
// // //   providedIn: 'root'
// // // })
// // // export class AuthService {
// // //   private http = inject(HttpClient);
// // //   private apiUrl = 'http://127.0.0.1:5000/auth';

// // //   // המשתנה שיחזיק את נתוני המשתמש המחובר לכל אורך חיי האפליקציה
// // //   public currentUser: any = null;

// // //   // constructor() {
// // //   //   // כשמפעילים את האפליקציה, בודקים אם יש משתמש בזיכרון של הדפדפן
// // //   //   const savedUser = localStorage.getItem('user');
// // //   //   if (savedUser) {
// // //   //     this.currentUser = JSON.parse(savedUser);
// // //   //   }
// // //   // }


// // //   constructor(private http: HttpClient) {
// // //   const data = localStorage.getItem('user');
  
// // //   // התיקון: בודקים שהדאטה קיים, שהוא לא null, ושהוא לא המחרוזת "undefined"
// // //   if (data && data !== "undefined" && data !== null) {
// // //     try {
// // //       this.currentUser = JSON.parse(data);
// // //     } catch (e) {
// // //       console.error("Failed to parse user data", e);
// // //       this.currentUser = null;
// // //       localStorage.removeItem('user'); // מנקים נתון פגום
// // //     }
// // //   } else {
// // //     this.currentUser = null;
// // //   }
// // // }

// // //   // פונקציית כניסה
// // //   // login(credentials: any): Observable<any> {
// // //   //   return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
// // //   //     tap((res: any) => {
// // //   //       // ברגע שהתקבל אישור מהשרת, שומרים את האובייקט ב-Service
// // //   //       this.currentUser = res.user;
// // //   //       // ושומרים בזיכרון הדפדפן כדי שברענון דף המשתמש לא יתנתק
// // //   //       localStorage.setItem('user', JSON.stringify(res.user));
// // //   //     })
// // //   //   );
// // //   // }

// // //   login(credentials: any): Observable<any> {
// // //   return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
// // //     tap((res: any) => {
// // //       if (res && res.user) {
// // //         this.currentUser = res.user;
// // //         localStorage.setItem('user', JSON.stringify(res.user));
// // //       } else {
// // //         console.error('Login successful but no user data received');
// // //       }
// // //     })
// // //   );
// // // }

// // //   // פונקציית הרשמה
// // //   register(userData: any): Observable<any> {
// // //     return this.http.post(`${this.apiUrl}/register`, userData);
// // //   }

// // //   // התנתקות
// // //   logout() {
// // //     this.currentUser = null;
// // //     localStorage.removeItem('user');
// // //   }
// // // }



// // import { Injectable, inject } from '@angular/core';
// // import { HttpClient } from '@angular/common/http';
// // import { Observable, tap } from 'rxjs';

// // @Injectable({
// //   providedIn: 'root'
// // })
// // export class AuthService {
// //   // שימוש ב-inject (הדרך המומלצת באנגולר 16+)
// //   private http = inject(HttpClient);
// //   private apiUrl = 'http://127.0.0.1:5000/auth';

// //   // המשתנה שיחזיק את נתוני המשתמש
// //   public currentUser: any = null;

// //   constructor() {
// //     // טעינת המשתמש מהזיכרון ברגע שהשירות עולה
// //     this.loadUserFromStorage();
// //   }

// //   private loadUserFromStorage() {
// //     const data = localStorage.getItem('user');
    
// //     // הגנה מפני ערכי null או "undefined" כטקסט
// //     if (data && data !== "undefined" && data !== "null") {
// //       try {
// //         this.currentUser = JSON.parse(data);
// //       } catch (e) {
// //         console.error("Failed to parse user data from localStorage", e);
// //         this.logout(); // ניקוי במקרה של דאטה משובש
// //       }
// //     } else {
// //       this.currentUser = null;
// //     }
// //   }

// //   // פונקציית כניסה
// //   login(credentials: any): Observable<any> {
// //     return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
// //       tap((res: any) => {
// //         // בדיקה שהתגובה מהשרת מכילה משתמש לפני השמירה
// //         if (res && res.user) {
// //           this.currentUser = res.user;
// //           localStorage.setItem('user', JSON.stringify(res.user));
// //         }
// //       })
// //     );
// //   }

// //   // פונקציית הרשמה
// //   register(userData: any): Observable<any> {
// //     return this.http.post(`${this.apiUrl}/register`, userData);
// //   }

// //   // התנתקות
// //   logout() {
// //     this.currentUser = null;
// //     localStorage.removeItem('user');
// //   }
// // }

// import { Injectable, inject } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable, tap } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   private http = inject(HttpClient);
//   private apiUrl = 'http://127.0.0.1:5000/auth';

//   public currentUser: any = null;

//   constructor() {
//     this.loadUserFromStorage();
//   }

//   private loadUserFromStorage() {
//     const data = localStorage.getItem('user');
//     if (data && data !== "undefined" && data !== "null") {
//       try {
//         this.currentUser = JSON.parse(data);
//       } catch (e) {
//         this.logout();
//       }
//     }
//   }

//   // עדכון הזיכרון המשותף לשתי הפונקציות
//   private handleAuthResponse(res: any) {
//     if (res && res.user) {
//       this.currentUser = res.user;
//       localStorage.setItem('user', JSON.stringify(res.user));
//     }
//   }

//   // פונקציית כניסה - עכשיו מעדכנת את המשתמש
//   login(credentials: any): Observable<any> {
//     return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
//       tap(res => this.handleAuthResponse(res))
//     );
//   }

//   // פונקציית הרשמה - עכשיו גם היא מעדכנת את המשתמש מיד
//   register(userData: any): Observable<any> {
//     return this.http.post(`${this.apiUrl}/register`, userData).pipe(
//       tap(res => this.handleAuthResponse(res))
//     );
//   }
// //פונקצית עדכון הגשת בקשה
// //   requestUpgrade(email: string): Observable<any> {
// //   return this.http.post(`${this.apiUrl}/request-upgrade`, { email }).pipe(
// //     tap((res: any) => {
// //       if (res.status === 'success') {
// //         // חשוב! מעדכנים את המשתמש המקומי במחסנית כדי שה-UI יתעדכן מיד
// //         this.currentUser.role = res.newRole;
// //         localStorage.setItem('user', JSON.stringify(this.currentUser));
// //       }
// //     })
// //   );
// // }
// requestUpgrade(email: string): Observable<any> {
//   // ה-return כאן קריטי כדי שה-subscribe באמא יעבוד!
//   return this.http.post(`${this.apiUrl}/request-upgrade`, { email }).pipe(
//     tap((res: any) => {
//       console.log('תשובה מהשרת:', res);
//       if (this.currentUser) {
//         this.currentUser.role = res.newRole; // מעדכן את האובייקט המקומי
//         localStorage.setItem('user', JSON.stringify(this.currentUser));
//       }
//     })
//   );
// }

// // auth.service.ts

// // קבלת רשימת הממתינים
// getPendingUsers(): Observable<any[]> {
//   const role = this.currentUser?.role || '';
//   return this.http.get<any[]>(`${this.apiUrl}/pending-users`, {
//     headers: { 'x-user-role': role }
//   });
// }

// // אישור משתמש
// // approveUser(userId: number): Observable<any> {
// //   const role = this.currentUser?.role || '';
// //   return this.http.post(`${this.apiUrl}/approve-user/${userId}`, {}, {
// //     headers: { 'x-user-role': role }
// //   });
// // }
// // auth.service.ts

// approveUser(userId: number): Observable<any> {
//   const role = this.currentUser?.role || '';
//   return this.http.post(`${this.apiUrl}/approve-user/${userId}`, {}, {
//     headers: { 'x-user-role': role }
//   });
// }


//   logout() {
//     this.currentUser = null;
//     localStorage.removeItem('user');
//   }
// }

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // הוספנו HttpHeaders
import { Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private apiUrl = 'http://127.0.0.1:5000/auth';

  public currentUser: any = null;

  constructor() {
    this.loadUserFromStorage();
  }

  /**
   * יצירת Headers עם התפקיד של המשתמש.
   * זהו שלב קריטי כדי שהדקורטור ב-Python יוכל לאמת את המנהל.
   */
  private getAuthHeaders(): HttpHeaders {
    const role = this.currentUser?.role || '';
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'x-user-role': role
    });
  }

  private loadUserFromStorage() {
    const data = localStorage.getItem('user');
    if (data && data !== "undefined" && data !== "null") {
      try {
        this.currentUser = JSON.parse(data);
      } catch (e) {
        this.logout();
      }
    }
  }

  private handleAuthResponse(res: any) {
    if (res && res.user) {
      this.currentUser = res.user;
      localStorage.setItem('user', JSON.stringify(res.user));
    }
  }

  login(credentials: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials).pipe(
      tap(res => this.handleAuthResponse(res))
    );
  }

  register(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, userData).pipe(
      tap(res => this.handleAuthResponse(res))
    );
  }

  requestUpgrade(email: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/request-upgrade`, { email }).pipe(
      tap((res: any) => {
        if (this.currentUser) {
          this.currentUser.role = res.newRole;
          localStorage.setItem('user', JSON.stringify(this.currentUser));
        }
      })
    );
  }

  /**
   * קבלת רשימת משתמשים הממתינים לאישור (רק למנהל)
   */
  getPendingUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/pending-users`, {
      headers: this.getAuthHeaders() // שימוש ב-Headers המרוכזים
    });
  }

  /**
   * אישור משתמש ושדרוגו ל-Uploader
   */
  approveUser(userId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/approve-user/${userId}`, {}, {
      headers: this.getAuthHeaders() // שימוש ב-Headers המרוכזים
    });
  }

  logout() {
    this.currentUser = null;
    localStorage.removeItem('user');
  }
}